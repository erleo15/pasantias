export { BlankLayoutCardComponent } from './blank-layout-card.component';
