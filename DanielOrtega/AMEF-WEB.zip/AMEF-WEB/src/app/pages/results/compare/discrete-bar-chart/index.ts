export { DiscreteBarChartComponent } from './discrete-bar-chart.component';
