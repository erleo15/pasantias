export { CompareComponent } from './compare.component';
export { CompareModule } from './compare.module';
