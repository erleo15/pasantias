export { PaginationComponent } from './pagination.component';
