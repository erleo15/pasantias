export { SwitchComponent } from './switch.component';
