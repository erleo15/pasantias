export { ToggleComponent } from './toggle.component';
