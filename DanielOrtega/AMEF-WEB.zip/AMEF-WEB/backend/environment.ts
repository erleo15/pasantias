export const environment = {
    database : "amef"
  };