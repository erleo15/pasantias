package dortegam.dataproc.extractor.metadata.search;

import java.util.Set;

public class MetadataSearchProperty {

    String name;

    Set<String> values;

}
