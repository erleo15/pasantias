package dortegam.dataproc.extractor;

public interface Search {
}
