package amef.queue;

public interface QueueMessage {

    String getBody();

}
